const QuoteFollowup = require("../../models/quote/quoteFollowup");

exports.createFollowup = async (req, res) => {
  try {
    const followup = await QuoteFollowup.create(req.body);
    res.status(201).json(followup);
  } catch (err) {
    res
      .status(500)
      .json({ error: "Failed to create quote followup", details: err });
  }
};

exports.getAllFollowups = async (req, res) => {
  try {
    const followups = await QuoteFollowup.findAll();
    res.status(200).json(followups);
  } catch (err) {
    res.status(500).json({ error: "Failed to fetch followups" });
  }
};

exports.getFollowupById = async (req, res) => {
  try {
    const followup = await QuoteFollowup.findByPk(req.params.id);
    if (!followup)
      return res.status(404).json({ message: "Followup not found" });
    res.status(200).json(followup);
  } catch (err) {
    res.status(500).json({ error: "Failed to fetch followup" });
  }
};

exports.updateFollowup = async (req, res) => {
  try {
    await QuoteFollowup.update(req.body, { where: { id: req.params.id } });
    res.status(200).json({ message: "Followup updated successfully" });
  } catch (err) {
    res.status(500).json({ error: "Failed to update followup" });
  }
};

exports.deleteFollowup = async (req, res) => {
  try {
    await QuoteFollowup.destroy({ where: { id: req.params.id } });
    res.status(200).json({ message: "Followup deleted successfully" });
  } catch (err) {
    res.status(500).json({ error: "Failed to delete followup" });
  }
};
