const { DataTypes } = require("sequelize");
const sequelize = require("../../config/database");

const QuoteFollowup = sequelize.define(
  "QuoteFollowup",
  {
    enquiry_id: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    category: DataTypes.TEXT,
    foll_date: DataTypes.DATEONLY,
    foll_time: DataTypes.TEXT,
    staff_name: DataTypes.TEXT,
    response: DataTypes.TEXT,
    description: DataTypes.TEXT,
    nxtfoll: DataTypes.DATEONLY,
    staffame: DataTypes.TEXT,
    colorcode: DataTypes.TEXT,
  },
  {
    tableName: "quote_followups",
    timestamps: true,
  }
);

module.exports = QuoteFollowup;
