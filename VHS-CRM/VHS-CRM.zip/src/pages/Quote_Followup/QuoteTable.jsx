import React from "react";

function QuoteTable() {
  return <div>QuoteTable</div>;
}

export default QuoteTable;
