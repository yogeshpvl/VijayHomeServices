import React from "react";

function PaymentCollect() {
  return <div>PaymentCollect</div>;
}

export default PaymentCollect;
