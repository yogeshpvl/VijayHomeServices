import React from "react";

function PRInvoice() {
  return <div>PRInvoice</div>;
}

export default PRInvoice;
