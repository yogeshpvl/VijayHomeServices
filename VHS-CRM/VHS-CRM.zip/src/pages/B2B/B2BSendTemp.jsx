import React from "react";

function B2BSendTemp() {
  return <div>B2BSendTemp</div>;
}

export default B2BSendTemp;
