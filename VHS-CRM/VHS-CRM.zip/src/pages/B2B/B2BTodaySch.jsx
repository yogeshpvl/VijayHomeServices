import React from "react";

function B2BTodaySch() {
  return <div>B2BTodaySch</div>;
}

export default B2BTodaySch;
