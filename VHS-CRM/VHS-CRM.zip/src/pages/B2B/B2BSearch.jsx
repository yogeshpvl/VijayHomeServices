import React from "react";

function B2BSearch() {
  return <div>B2BSearch</div>;
}

export default B2BSearch;
