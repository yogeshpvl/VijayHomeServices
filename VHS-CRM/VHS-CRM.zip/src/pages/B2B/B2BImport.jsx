import React from "react";

function B2BImport() {
  return <div>B2BImport</div>;
}

export default B2BImport;
