import React from "react";

function B2BAdd() {
  return <div>B2BAdd</div>;
}

export default B2BAdd;
