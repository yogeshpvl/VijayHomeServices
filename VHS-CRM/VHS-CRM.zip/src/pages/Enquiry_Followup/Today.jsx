import React from "react";

function Today() {
  return <div>Today</div>;
}

export default Today;
