import React from "react";

function SurveyCancelled() {
  return <div>SurveyCancelled</div>;
}

export default SurveyCancelled;
