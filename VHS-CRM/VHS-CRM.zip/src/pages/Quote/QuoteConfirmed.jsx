import React from "react";

function QuoteConfirmed() {
  return <div>QuoteConfirmed</div>;
}

export default QuoteConfirmed;
