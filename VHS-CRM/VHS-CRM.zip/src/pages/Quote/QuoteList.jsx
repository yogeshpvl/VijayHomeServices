import React from "react";

function QuoteList() {
  return <div>QuoteList</div>;
}

export default QuoteList;
