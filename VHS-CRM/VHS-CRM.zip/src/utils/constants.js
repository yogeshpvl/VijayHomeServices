// styles/constants.js
const theme = {
  primary: "#2c3e50",
  secondary: "#007bff",
  text: "#333",
  background: "#f8f9fa",
  active: "darkred",
  white: "#ffffff",
};

export default theme;
